#!/usr/bin/env python3
"""Assemble a signed Kanaf APK from the production static bundle."""

import os
import shutil
import struct
import subprocess
import zlib
import zipfile
from pathlib import Path

ROOT = Path("/tmp/kanaf-android")
SDK = Path("/tmp/android-sdk")
BT = SDK / "android-15"
ANDROID_JAR = SDK / "android.jar"
STATIC = Path("/workspace/.vercel/output/static")
OUT = Path("/workspace/artifacts/Kanaf.apk")
BUILD = ROOT / "build"
KEYSTORE = ROOT / "kanaf-release.jks"


def chunk(tag: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)


def png(w: int, h: int, pixels: bytes) -> bytes:
    raw = b"".join(b"\x00" + pixels[y * w * 4 : (y + 1) * w * 4] for y in range(h))
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")


def bezier(p0, p1, p2, p3, steps=28):
    pts = []
    for i in range(steps + 1):
        t = i / steps
        u = 1 - t
        x = u**3 * p0[0] + 3 * u**2 * t * p1[0] + 3 * u * t**2 * p2[0] + t**3 * p3[0]
        y = u**3 * p0[1] + 3 * u**2 * t * p1[1] + 3 * u * t**2 * p2[1] + t**3 * p3[1]
        pts.append((x, y))
    return pts


def inside(x, y, poly):
    hit = False
    j = len(poly) - 1
    for i, (xi, yi) in enumerate(poly):
        xj, yj = poly[j]
        if (yi > y) != (yj > y):
            cross = (xj - xi) * (y - yi) / ((yj - yi) or 1e-9) + xi
            if x < cross:
                hit = not hit
        j = i
    return hit


SHIELD = (
    [(60, 6), (108, 28), (108, 68)]
    + bezier((108, 68), (108, 100), (88, 122), (60, 134))[1:]
    + bezier((60, 134), (32, 122), (12, 100), (12, 68))[1:]
    + [(12, 28)]
)
MARK = [(46, 46), (56, 46), (56, 62), (70, 46), (83, 46), (63, 70), (85, 96), (72, 96), (58, 76), (58, 96), (46, 96)]


def icon(size: int) -> bytes:
    scale = 2
    big = size * scale
    pixels = bytearray(big * big * 4)
    radius = big * 0.22
    shield_s = big * 0.70 / 140
    ox = (big - 120 * shield_s) / 2
    oy = (big - 140 * shield_s) / 2 + big * 0.01

    def project(poly, grow=1.0):
        cx, cy = 60, 70
        out = []
        for x, y in poly:
            out.append((ox + (cx + (x - cx) * grow) * shield_s, oy + (cy + (y - cy) * grow) * shield_s))
        return out

    gold = project(SHIELD, 1.045)
    body = project(SHIELD, 1.0)
    mark = project(MARK, 1.0)
    for y in range(big):
        for x in range(big):
            i = (y * big + x) * 4
            dx = min(x, big - 1 - x)
            dy = min(y, big - 1 - y)
            # rounded-rect background matching the in-app navy
            ax = big / 2 - abs(x + 0.5 - big / 2)
            ay = big / 2 - abs(y + 0.5 - big / 2)
            outside = ax < radius and ay < radius and (radius - ax) ** 2 + (radius - ay) ** 2 > radius * radius
            if outside:
                pixels[i : i + 4] = b"\x00\x00\x00\x00"
                continue
            shade = int(7 + 10 * (1 - y / big))
            pixels[i : i + 4] = bytes((shade, 17, 31, 255))
            px, py = x + 0.5, y + 0.5
            if inside(px, py, gold):
                pixels[i : i + 4] = bytes((231, 194, 122, 255))
            if inside(px, py, body):
                tone = int(7 + 22 * (1 - (py - oy) / (140 * shield_s)))
                pixels[i : i + 4] = bytes((max(7, tone), 20 + tone // 3, 40 + tone // 2, 255))
            if inside(px, py, mark):
                pixels[i : i + 4] = bytes((92, 225, 255, 255))
    raw = bytearray(size * size * 4)
    for y in range(size):
        for x in range(size):
            acc = [0, 0, 0, 0]
            for oy2 in range(scale):
                for ox2 in range(scale):
                    src = ((y * scale + oy2) * big + (x * scale + ox2)) * 4
                    for c in range(4):
                        acc[c] += pixels[src + c]
            dest = (y * size + x) * 4
            raw[dest : dest + 4] = bytes(channel // (scale * scale) for channel in acc)
    return png(size, size, bytes(raw))


def write_icons() -> None:
    sizes = {
        "mipmap-mdpi": 48,
        "mipmap-hdpi": 72,
        "mipmap-xhdpi": 96,
        "mipmap-xxhdpi": 144,
        "mipmap-xxxhdpi": 192,
    }
    for folder, size in sizes.items():
        dest = ROOT / "res" / folder / "ic_launcher.png"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(icon(size))


def run(cmd: list[str]) -> None:
    print("+", " ".join(cmd))
    subprocess.run(cmd, check=True)


def stage_web() -> Path:
    web = BUILD / "web"
    if web.exists():
        shutil.rmtree(web)
    shutil.copytree(STATIC, web, ignore=shutil.ignore_patterns("install"))
    html = subprocess.check_output(
        [
            "node",
            "--input-type=module",
            "-e",
            "import handler from './index.mjs';"
            "const res = await handler.fetch(new Request('https://appassets.androidplatform.net/'));"
            "if (!res.ok) throw new Error(String(res.status));"
            "process.stdout.write(await res.text());",
        ],
        cwd="/workspace/.vercel/output/functions/__server.func",
    )
    (web / "index.html").write_bytes(html)
    manifest = web / "__grok" / "manifest.webmanifest"
    manifest.write_text(
        """{
  "name": "Kanaf",
  "short_name": "Kanaf",
  "id": "/",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "background_color": "#07111F",
  "theme_color": "#07111F",
  "icons": [{ "src": "/__grok/icon-180.png", "sizes": "180x180", "type": "image/png" }]
}
""",
        encoding="utf-8",
    )
    return web


def pack(web: Path, dex: Path, base_apk: Path, merged: Path) -> None:
    with zipfile.ZipFile(base_apk, "r") as zin, zipfile.ZipFile(merged, "w") as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            info = zipfile.ZipInfo(filename=item.filename, date_time=(2008, 1, 1, 0, 0, 0))
            info.compress_type = item.compress_type
            info.external_attr = item.external_attr
            zout.writestr(info, data)
        info = zipfile.ZipInfo(filename="classes.dex", date_time=(2008, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_STORED
        zout.writestr(info, dex.read_bytes())
        for path in web.rglob("*"):
            if not path.is_file():
                continue
            rel = "assets/" + path.relative_to(web).as_posix()
            info = zipfile.ZipInfo(filename=rel, date_time=(2008, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            zout.writestr(info, path.read_bytes())


def main() -> None:
    if BUILD.exists():
        shutil.rmtree(BUILD)
    BUILD.mkdir(parents=True)
    write_icons()
    web = stage_web()
    compiled = BUILD / "compiled.zip"
    run([str(BT / "aapt2"), "compile", "--dir", str(ROOT / "res"), "-o", str(compiled)])
    base = BUILD / "base.apk"
    run(
        [
            str(BT / "aapt2"),
            "link",
            "-o",
            str(base),
            "-I",
            str(ANDROID_JAR),
            "--manifest",
            str(ROOT / "AndroidManifest.xml"),
            "--min-sdk-version",
            "24",
            "--target-sdk-version",
            "34",
            str(compiled),
        ]
    )
    classes = BUILD / "classes"
    classes.mkdir()
    java = list((ROOT / "src").rglob("*.java"))
    run(
        [
            "javac",
            "--release",
            "11",
            "-encoding",
            "UTF-8",
            "-classpath",
            str(ANDROID_JAR),
            "-d",
            str(classes),
            *map(str, java),
        ]
    )
    dex_dir = BUILD / "dex"
    dex_dir.mkdir()
    class_files = [str(path) for path in classes.rglob("*.class")]
    run([str(BT / "d8"), "--min-api", "24", "--lib", str(ANDROID_JAR), "--output", str(dex_dir), *class_files])
    merged = BUILD / "merged.apk"
    pack(web, dex_dir / "classes.dex", base, merged)
    aligned = BUILD / "aligned.apk"
    run([str(BT / "zipalign"), "-p", "-f", "4", str(merged), str(aligned)])
    if not KEYSTORE.exists():
        run(
            [
                "keytool",
                "-genkeypair",
                "-keystore",
                str(KEYSTORE),
                "-storepass",
                "kanaf-release",
                "-keypass",
                "kanaf-release",
                "-alias",
                "kanaf",
                "-keyalg",
                "RSA",
                "-keysize",
                "2048",
                "-validity",
                "10000",
                "-dname",
                "CN=Kanaf, O=Kanaf, C=SA",
            ]
        )
    OUT.parent.mkdir(parents=True, exist_ok=True)
    if OUT.exists():
        OUT.unlink()
    run(
        [
            str(BT / "apksigner"),
            "sign",
            "--ks",
            str(KEYSTORE),
            "--ks-pass",
            "pass:kanaf-release",
            "--key-pass",
            "pass:kanaf-release",
            "--ks-key-alias",
            "kanaf",
            "--out",
            str(OUT),
            str(aligned),
        ]
    )
    run([str(BT / "apksigner"), "verify", "--verbose", str(OUT)])
    print("APK", OUT, OUT.stat().st_size)


if __name__ == "__main__":
    main()
