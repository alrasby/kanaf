package com.kanaf.alrasby;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;

import java.io.File;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.UUID;

/** Watches new installs and downloads while the user has real-time protection on. */
public class WatchService extends Service {
    static final String ACTION_START = "com.kanaf.alrasby.WATCH_START";
    static final String ACTION_STOP = "com.kanaf.alrasby.WATCH_STOP";
    private static final String CHANNEL = "kanaf-watch";
    private static final int NOTE = 41;

    private BroadcastReceiver packages;
    private ContentObserver downloads;
    private boolean registered;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopWatching();
            if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
            else stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        ensureChannel();
        Notification notification = buildNote("Kanaf is watching new installs and downloads.", true);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTE, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTE, notification);
        }
        register();
        new Thread(new Runnable() {
            @Override
            public void run() {
                baselineCerts();
            }
        }, "kanaf-certs").start();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopWatching();
        super.onDestroy();
    }

    private void register() {
        if (registered) return;
        packages = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || intent.getData() == null) return;
                String pkg = intent.getData().getSchemeSpecificPart();
                if (pkg == null || pkg.equals(getPackageName())) return;
                boolean replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false);
                if (replacing) {
                    watchCert(pkg, true);
                    return;
                }
                watchCert(pkg, false);
                try {
                    ApplicationInfo info = getPackageManager().getApplicationInfo(pkg, 0);
                    if (info.sourceDir == null) return;
                    String id = UUID.randomUUID().toString();
                    CharSequence label = getPackageManager().getApplicationLabel(info);
                    String name = (label == null ? pkg : label.toString()) + ".apk";
                    boolean handed = MainActivity.rememberLive(id, new File(info.sourceDir), null, name);
                    if (riskyInstall(pkg)) alert("Suspicious install behavior", name);
                    else if (!handed) alert("New app installed", name);
                } catch (Exception ignored) {
                    alert("New app installed", pkg);
                }
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_PACKAGE_ADDED);
        filter.addDataScheme("package");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packages, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(packages, filter);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            downloads = new ContentObserver(new Handler(Looper.getMainLooper())) {
                @Override
                public void onChange(boolean selfChange) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            scanLatestDownload();
                        }
                    }, "kanaf-download").start();
                }
            };
            getContentResolver().registerContentObserver(MediaStore.Downloads.EXTERNAL_CONTENT_URI, true, downloads);
        }
        registered = true;
    }

    private long lastDownloadAt;
    private String lastDownloadId = "";

    private void scanLatestDownload() {
        if (Build.VERSION.SDK_INT < 29) return;
        synchronized (this) {
            long now = System.currentTimeMillis();
            if (now - lastDownloadAt < 4000L) return;
            lastDownloadAt = now;
            Cursor cursor = null;
            try {
                cursor = getContentResolver().query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    new String[] {MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.DATE_ADDED},
                    null,
                    null,
                    MediaStore.Downloads.DATE_ADDED + " DESC"
                );
                if (cursor == null || !cursor.moveToFirst()) return;
                long added = cursor.getLong(2);
                if (added < System.currentTimeMillis() / 1000L - 120L) return;
                String mediaKey = String.valueOf(cursor.getLong(0));
                if (mediaKey.equals(lastDownloadId)) return;
                String name = cursor.getString(1);
                if (name == null || name.length() == 0) name = "download";
                if (!interesting(name)) return;
                lastDownloadId = mediaKey;
                Uri uri = android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cursor.getLong(0));
                cursor.close();
                cursor = null;
                String id = UUID.randomUUID().toString();
                boolean handed = MainActivity.rememberLive(id, null, uri, name);
                if (handed) return;
                Digest digest = hashUri(uri);
                if (digest == null) {
                    alert("New download", name);
                    return;
                }
                if (!MainActivity.postHash(name, digest.sha, digest.size)) rememberHash(name, digest.sha, digest.size);
            } catch (Exception ignored) {
                /* downloads not visible */
            } finally {
                if (cursor != null) cursor.close();
            }
        }
    }

    private boolean interesting(String name) {
        String lower = name.toLowerCase(Locale.US);
        return lower.endsWith(".apk") || lower.endsWith(".xapk") || lower.endsWith(".apks")
            || lower.endsWith(".zip") || lower.endsWith(".jar") || lower.endsWith(".rar")
            || lower.endsWith(".docm") || lower.endsWith(".xlsm") || lower.endsWith(".exe");
    }

    private Digest hashUri(Uri uri) {
        InputStream in = null;
        try {
            in = getContentResolver().openInputStream(uri);
            if (in == null) return null;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[65536];
            long total = 0;
            int n;
            while ((n = in.read(buf)) >= 0) {
                total += n;
                if (total > 96L * 1024L * 1024L) return null;
                digest.update(buf, 0, n);
            }
            byte[] raw = digest.digest();
            StringBuilder hex = new StringBuilder(raw.length * 2);
            for (byte value : raw) hex.append(String.format(Locale.US, "%02x", value));
            Digest out = new Digest();
            out.sha = hex.toString();
            out.size = total;
            return out;
        } catch (Exception error) {
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception ignored) {
                    /* closed */
                }
            }
        }
    }

    private void rememberHash(String name, String sha, long size) {
        try {
            android.content.SharedPreferences prefs = getSharedPreferences("kanaf", MODE_PRIVATE);
            org.json.JSONArray rows = new org.json.JSONArray(prefs.getString("pending-hash", "[]"));
            while (rows.length() >= 8) rows.remove(0);
            org.json.JSONObject row = new org.json.JSONObject();
            row.put("name", name);
            row.put("sha", sha);
            row.put("size", size);
            rows.put(row);
            prefs.edit().putString("pending-hash", rows.toString()).apply();
        } catch (Exception ignored) {
            /* queue stays unchanged */
        }
    }

    private static final class Digest {
        String sha;
        long size;
    }

    static void ping(Context context, String text) {
        NotificationManager manager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        if (manager == null || text == null || text.length() == 0) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Kanaf protection", NotificationManager.IMPORTANCE_DEFAULT);
            manager.createNotificationChannel(channel);
        }
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, 1, open, Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(context, CHANNEL)
            : new Notification.Builder(context);
        manager.notify(
            1000 + Math.abs(text.hashCode() % 10000),
            builder.setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle("Kanaf").setContentText(text).setAutoCancel(true).setContentIntent(pending).build()
        );
    }

    private void alert(String title, String body) {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        manager.notify(nameHash(body), buildNote(title + ": " + body, false));
    }

    private int nameHash(String body) {
        return 1000 + Math.abs(body.hashCode() % 10000);
    }

    private void stopWatching() {
        if (packages != null) {
            try {
                unregisterReceiver(packages);
            } catch (Exception ignored) {
                /* already gone */
            }
            packages = null;
        }
        if (downloads != null) {
            getContentResolver().unregisterContentObserver(downloads);
            downloads = null;
        }
        registered = false;
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Kanaf protection", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("Alerts when a new install or download is waiting for your decision.");
        manager.createNotificationChannel(channel);
    }

    private Notification buildNote(String text, boolean ongoing) {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(
            this,
            0,
            open,
            Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL)
            : new Notification.Builder(this);
        return builder
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Kanaf")
            .setContentText(text)
            .setContentIntent(pending)
            .setOngoing(ongoing)
            .build();
    }

    private boolean riskyInstall(String pkg) {
        if (pkg.startsWith("com.google.") || pkg.startsWith("com.android.") || pkg.startsWith("android.")
            || pkg.startsWith("com.samsung.") || pkg.startsWith("com.sec.") || pkg.startsWith("com.microsoft.")
            || pkg.startsWith("com.whatsapp")) return false;
        try {
            PackageInfo info = getPackageManager().getPackageInfo(pkg, PackageManager.GET_PERMISSIONS | PackageManager.GET_SERVICES);
            boolean overlay = false;
            boolean sms = false;
            boolean access = false;
            if (info.requestedPermissions != null) {
                for (String perm : info.requestedPermissions) {
                    if ("android.permission.SYSTEM_ALERT_WINDOW".equals(perm)) overlay = true;
                    if ("android.permission.RECEIVE_SMS".equals(perm) || "android.permission.READ_SMS".equals(perm)) sms = true;
                }
            }
            if (info.services != null) {
                for (ServiceInfo service : info.services) {
                    if ("android.permission.BIND_ACCESSIBILITY_SERVICE".equals(service.permission)) access = true;
                }
            }
            boolean launcher = getPackageManager().getLaunchIntentForPackage(pkg) != null;
            if (sms && access) {
                alert("SMS and accessibility", pkg);
                return true;
            }
            if (sms && overlay) {
                alert("SMS and screen overlay", pkg);
                return true;
            }
            if (overlay && access) {
                alert("Overlay and accessibility", pkg);
                return true;
            }
            return sms && !launcher;
        } catch (Exception error) {
            return false;
        }
    }

    private void baselineCerts() {
        try {
            java.util.List<PackageInfo> packs = getPackageManager().getInstalledPackages(0);
            for (PackageInfo info : packs) {
                if (info.applicationInfo == null) continue;
                if ((info.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                watchCert(info.packageName, false);
            }
        } catch (Exception ignored) {
            /* certificate book stays as it was */
        }
    }

    private void watchCert(String pkg, boolean replacing) {
        if (pkg == null || pkg.length() == 0 || pkg.length() > 180) return;
        String next = certHex(pkg);
        if (next.length() == 0) return;
        synchronized (WatchService.class) {
            try {
                android.content.SharedPreferences prefs = getSharedPreferences("kanaf", MODE_PRIVATE);
                org.json.JSONObject book = new org.json.JSONObject(prefs.getString("cert-book", "{}"));
                String prev = book.optString(pkg, "");
                if (prev.length() > 0 && !prev.equals(next)) {
                    org.json.JSONArray pending = new org.json.JSONArray(prefs.getString("pending-certs", "[]"));
                    while (pending.length() >= 12) pending.remove(0);
                    org.json.JSONObject row = new org.json.JSONObject();
                    row.put("pkg", pkg);
                    row.put("before", prev);
                    row.put("after", next);
                    pending.put(row);
                    book.put(pkg, next);
                    prefs.edit().putString("pending-certs", pending.toString()).putString("cert-book", book.toString()).apply();
                    alert("Signing certificate changed", pkg);
                } else if (prev.length() == 0) {
                    book.put(pkg, next);
                    prefs.edit().putString("cert-book", book.toString()).apply();
                }
            } catch (Exception ignored) {
                /* one package does not erase the book */
            }
        }
    }

    private String certHex(String pkg) {
        try {
            int flags = Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
            PackageInfo info = getPackageManager().getPackageInfo(pkg, flags);
            android.content.pm.Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) sigs = info.signingInfo.getApkContentsSigners();
            else sigs = info.signatures;
            if (sigs == null || sigs.length == 0) return "";
            byte[] dig = java.security.MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray());
            StringBuilder hex = new StringBuilder(dig.length * 2);
            for (byte value : dig) hex.append(String.format(Locale.US, "%02x", value));
            return hex.toString();
        } catch (Exception error) {
            return "";
        }
    }
}
