package com.kanaf.alrasby;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Reads notification previews the user has allowed, and only when a link is visible. */
public class NoticeWatch extends NotificationListenerService {
    @Override
    public void onNotificationPosted(StatusBarNotification posted) {
        if (posted == null || getPackageName().equals(posted.getPackageName())) return;
        Notification note = posted.getNotification();
        if (note == null || note.extras == null) return;
        Bundle extras = note.extras;
        StringBuilder body = new StringBuilder();
        append(body, extras.getCharSequence(Notification.EXTRA_TITLE));
        append(body, extras.getCharSequence(Notification.EXTRA_TEXT));
        append(body, extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
        CharSequence[] lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null) {
            for (CharSequence line : lines) append(body, line);
        }
        if (body.length() > 4000) body.setLength(4000);
        String text = body.toString();
        String lower = text.toLowerCase();
        if (!lower.contains("http") && !lower.contains("www.") && !lower.contains(".com") && !lower.contains(".om") && !lower.contains(".net")) return;
        if (MainActivity.postNotice(text)) return;
        getSharedPreferences("kanaf", MODE_PRIVATE).edit().putString("pending-notice", text).apply();
        WatchService.ping(this, "Link in a notification");
    }

    private static void append(StringBuilder body, CharSequence value) {
        if (value == null || value.length() == 0) return;
        if (body.length() > 0) body.append('\n');
        body.append(value);
    }
}
