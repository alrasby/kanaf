package com.kanaf.alrasby;

import android.content.SharedPreferences;
import android.telecom.Call;
import android.telecom.CallScreeningService;
import org.json.JSONArray;
import org.json.JSONObject;

/** Refuses a call only after the user made Kanaf the screening app. */
public class CallScreen extends CallScreeningService {
    @Override
    public void onScreenCall(Call.Details details) {
        boolean block = false;
        try {
            String handle = details.getHandle() == null ? "" : details.getHandle().getSchemeSpecificPart();
            String digits = handle == null ? "" : handle.replaceAll("\\D", "");
            if (digits.startsWith("882") || digits.startsWith("883") || digits.startsWith("979")) block = true;
            SharedPreferences prefs = getSharedPreferences("kanaf", MODE_PRIVATE);
            JSONObject root = new JSONObject(prefs.getString("call-policy", "{}"));
            if (listed(root.optJSONArray("official"), digits)) block = false;
            else if (listed(root.optJSONArray("blocked"), digits)) block = true;
            if (digits.length() < 8) block = false;
        } catch (Exception ignored) {
            block = false;
        }
        CallResponse.Builder answer = new CallResponse.Builder();
        if (block) {
            answer.setDisallowCall(true);
            answer.setRejectCall(true);
            answer.setSkipNotification(false);
        }
        respondToCall(details, answer.build());
    }

    private static boolean listed(JSONArray rows, String digits) {
        if (rows == null || digits.length() < 8) return false;
        for (int i = 0; i < rows.length(); i++) {
            String other = rows.optString(i, "").replaceAll("\\D", "");
            if (other.length() >= 8 && (digits.endsWith(other) || other.endsWith(digits))) return true;
        }
        return false;
    }
}
