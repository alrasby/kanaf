package com.kanaf.alrasby;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.StatFs;
import android.os.storage.StorageManager;
import android.app.KeyguardManager;
import android.content.ClipData;
import android.content.ContentValues;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Sideload shell for Kanaf. The scanner UI is the bundled web app, loaded from a
 * secure local origin so storage and the vault keep working offline.
 */
public class MainActivity extends Activity {
    private static final String SIGNER = "3398d0113797518babcc9f981e9cb8db9971c5b77216e90273d4e6cd58331116";
    private static final String HOST = "appassets.androidplatform.net";
    private static final String ORIGIN = "https://" + HOST;
    private static final int PICK_TREE = 41;
    private static final int PICK_FILES = 42;
    private static final int PICK_TEXT = 43;
    private static final int PICK_CHOOSER = 44;
    private android.webkit.ValueCallback<android.net.Uri[]> fileCallback;
    private static final int MAX_FILES = 4000;

    private WebView web;
    private final Map<String, Uri> picked = new LinkedHashMap<String, Uri>();
    private String pickMode = "deep";
    private volatile boolean picking = false;
    static volatile MainActivity current;

    static final class Blob {
        final File file;
        final Uri uri;
        Blob(File file, Uri uri) {
            this.file = file;
            this.uri = uri;
        }
    }

    final Map<String, Blob> served = new LinkedHashMap<String, Blob>();
    private final Map<String, File> mailFiles = new LinkedHashMap<String, File>();
    private final Map<String, File> netFiles = new LinkedHashMap<String, File>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF07111F);
        getWindow().setNavigationBarColor(0xFF07111F);
        WebView.setWebContentsDebuggingEnabled(false);
        web = new WebView(this);
        web.setBackgroundColor(0xFF07111F);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        settings.setGeolocationEnabled(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        web.addJavascriptInterface(new Bridge(), "KanafNative");
        web.setWebChromeClient(new android.webkit.WebChromeClient() {
            @Override
            public void onPermissionRequest(final android.webkit.PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        for (String resource : request.getResources()) {
                            if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                                request.grant(new String[] {android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                                return;
                            }
                        }
                        request.deny();
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<android.net.Uri[]> callback, android.webkit.WebChromeClient.FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), PICK_CHOOSER);
                    return true;
                } catch (Exception error) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return intercept(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (HOST.equals(uri.getHost())) return false;
                String scheme = uri.getScheme();
                if ("https".equals(scheme) || "http".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {
                        /* no browser */
                    }
                    return true;
                }
                return true;
            }
        });
        setContentView(web);
        current = this;
        web.loadUrl(sharedTarget(getIntent()));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (web != null) web.loadUrl(sharedTarget(intent));
    }

    private String sharedTarget(Intent intent) {
        String text = sharedText(intent);
        if (text == null || text.length() == 0) return ORIGIN + "/";
        return ORIGIN + "/phish?text=" + Uri.encode(text);
    }

    private String sharedText(Intent intent) {
        if (intent == null) return null;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action)) return intent.getStringExtra(Intent.EXTRA_TEXT);
        if (Intent.ACTION_PROCESS_TEXT.equals(action)) return intent.getStringExtra(Intent.EXTRA_PROCESS_TEXT);
        return null;
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        super.onDestroy();
    }

    static boolean postNotice(String text) {
        MainActivity activity = current;
        if (activity == null || activity.web == null || text == null || text.length() == 0) return false;
        final String sample = text.length() > 4000 ? text.substring(0, 4000) : text;
        activity.web.post(new Runnable() {
            @Override
            public void run() {
                if (activity.web == null) return;
                activity.web.evaluateJavascript("window.__kanafNotice&&window.__kanafNotice(" + JSONObject.quote(sample) + ")", null);
            }
        });
        return true;
    }

    static boolean postHash(String name, String sha, long size) {
        MainActivity activity = current;
        if (activity == null || activity.web == null || sha == null) return false;
        final String label = name == null ? "" : name;
        activity.web.post(new Runnable() {
            @Override
            public void run() {
                if (activity.web == null) return;
                activity.web.evaluateJavascript(
                    "window.__kanafHash&&window.__kanafHash(" + JSONObject.quote(label) + "," + JSONObject.quote(sha) + "," + size + ")",
                    null
                );
            }
        });
        return true;
    }

    static boolean rememberLive(String id, File file, Uri uri, String name) {
        MainActivity activity = current;
        if (activity == null || activity.web == null) return false;
        synchronized (activity.served) {
            activity.served.put(id, new Blob(file, uri));
        }
        final String script = "window.__kanafLive&&window.__kanafLive(" + JSONObject.quote(id) + "," + JSONObject.quote(name) + ")";
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (activity.web != null) activity.web.evaluateJavascript(script, null);
            }
        });
        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web != null && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 77 || requestCode == 78) {
            deliverPerm(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);
        }
        if (requestCode == 79 && web != null) {
            web.evaluateJavascript("window.__kanafDevice&&window.__kanafDevice()", null);
        }
        if (requestCode == 80 && web != null) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            web.evaluateJavascript("window.__kanafCamera&&window.__kanafCamera(" + (granted ? "true" : "false") + ")", null);
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("kanaf", MODE_PRIVATE);
    }

    private void deliverPerm(final boolean granted) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web == null) return;
                web.evaluateJavascript("window.__kanafPerm&&window.__kanafPerm(" + (granted ? "true" : "false") + ")", null);
            }
        });
    }

    private String networkKind() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return "unknown";
            Network net = cm.getActiveNetwork();
            if (net == null) return "none";
            NetworkCapabilities caps = cm.getNetworkCapabilities(net);
            if (caps == null) return "unknown";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "wifi";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "cellular";
            return "other";
        } catch (Exception error) {
            return "unknown";
        }
    }

    private String readDevice() {
        JSONObject row = new JSONObject();
        try {
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            row.put("lock", km != null && km.isDeviceSecure());
            row.put("usb", Settings.Global.getInt(getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1);
            row.put("developer", Settings.Global.getInt(getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1);
            row.put("patch", Build.VERSION.SECURITY_PATCH == null ? "" : Build.VERSION.SECURITY_PATCH);
        } catch (Exception error) {
            return "{\"lock\":false,\"usb\":false,\"developer\":false,\"patch\":\"\"}";
        }
        return row.toString();
    }

    private WebResourceResponse mailFile(String id) {
        int slash = id.indexOf('/');
        if (slash >= 0) id = id.substring(0, slash);
        File file;
        synchronized (mailFiles) {
            file = mailFiles.get(id);
        }
        if (file == null || !file.isFile()) return missing();
        try {
            return new WebResourceResponse("application/octet-stream", null, new java.io.FileInputStream(file));
        } catch (Exception error) {
            return missing();
        }
    }

    private String collectMessages() {
        if (checkSelfPermission(android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            return "{\"status\":\"need\",\"messages\":[]}";
        }
        JSONArray messages = new JSONArray();
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(
                Uri.parse("content://sms/inbox"),
                new String[] {"_id", "address", "body", "date"},
                null,
                null,
                "date DESC"
            );
            int n = 0;
            if (cursor != null) {
                while (cursor.moveToNext() && n < 500) {
                    JSONObject row = new JSONObject();
                    row.put("id", cursor.isNull(0) ? "" : cursor.getString(0));
                    row.put("from", cursor.isNull(1) ? "" : cursor.getString(1));
                    row.put("body", cursor.isNull(2) ? "" : cursor.getString(2));
                    row.put("when", cursor.isNull(3) ? 0 : cursor.getLong(3));
                    row.put("kind", "sms");
                    messages.put(row);
                    n++;
                }
            }
        } catch (Exception error) {
            return "{\"status\":\"denied\",\"messages\":[]}";
        } finally {
            if (cursor != null) cursor.close();
        }
        try {
            appendMms(messages);
        } catch (Exception ignored) {
            /* mms provider unavailable */
        }
        JSONObject root = new JSONObject();
        try {
            root.put("status", "ok");
            root.put("messages", messages);
        } catch (Exception error) {
            return "{\"status\":\"empty\",\"messages\":[]}";
        }
        return root.toString();
    }

    private void appendMms(JSONArray messages) throws Exception {
        Cursor boxes = null;
        try {
            boxes = getContentResolver().query(Uri.parse("content://mms/inbox"), new String[] {"_id", "date"}, null, null, "date DESC");
            if (boxes == null) return;
            int n = 0;
            while (boxes.moveToNext() && n < 80) {
                String mid = boxes.getString(0);
                if (mid == null) continue;
                StringBuilder body = new StringBuilder();
                JSONArray files = new JSONArray();
                Cursor parts = null;
                try {
                    parts = getContentResolver().query(
                        Uri.parse("content://mms/part"),
                        new String[] {"_id", "ct", "name", "text", "cl"},
                        "mid=?",
                        new String[] {mid},
                        null
                    );
                    if (parts != null) {
                        while (parts.moveToNext()) {
                            String partId = parts.getString(0);
                            String type = parts.isNull(1) ? "" : parts.getString(1);
                            String name = parts.isNull(2) ? "" : parts.getString(2);
                            String text = parts.isNull(3) ? "" : parts.getString(3);
                            String location = parts.isNull(4) ? "" : parts.getString(4);
                            if (type.startsWith("text/") && !"application/smil".equals(type)) {
                                if (text.length() == 0 && partId != null) text = readPartText(partId);
                                if (text.length() > 0) body.append(text).append('\n');
                            } else if (partId != null && type.length() > 0 && !"application/smil".equals(type)) {
                                if (name.length() == 0) name = location.length() == 0 ? "attachment" : location;
                                File saved = copyPart(partId);
                                if (saved != null) {
                                    String id = UUID.randomUUID().toString();
                                    synchronized (mailFiles) {
                                        mailFiles.put(id, saved);
                                    }
                                    JSONObject file = new JSONObject();
                                    file.put("name", name);
                                    file.put("url", ORIGIN + "/__mms/" + id);
                                    files.put(file);
                                }
                            }
                        }
                    }
                } finally {
                    if (parts != null) parts.close();
                }
                if (body.length() == 0 && files.length() == 0) continue;
                JSONObject row = new JSONObject();
                row.put("id", mid);
                row.put("from", "mms");
                row.put("body", body.toString().trim());
                row.put("when", boxes.isNull(1) ? 0 : boxes.getLong(1) * 1000L);
                row.put("kind", "mms");
                row.put("files", files);
                messages.put(row);
                n++;
            }
        } finally {
            if (boxes != null) boxes.close();
        }
    }

    private String readPartText(String partId) {
        InputStream in = null;
        try {
            in = getContentResolver().openInputStream(Uri.parse("content://mms/part/" + partId));
            if (in == null) return "";
            byte[] buf = new byte[8192];
            int n = in.read(buf);
            if (n <= 0) return "";
            return new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception error) {
            return "";
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) { /* closed */ }
        }
    }

    private File copyPart(String partId) {
        InputStream in = null;
        FileOutputStream out = null;
        File dest = new File(getCacheDir(), "mms-" + partId);
        try {
            in = getContentResolver().openInputStream(Uri.parse("content://mms/part/" + partId));
            if (in == null) return null;
            out = new FileOutputStream(dest);
            byte[] buf = new byte[8192];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 12L * 1024L * 1024L) {
                    out.close();
                    out = null;
                    dest.delete();
                    return null;
                }
                out.write(buf, 0, n);
            }
            return dest.length() > 0 ? dest : null;
        } catch (Exception error) {
            dest.delete();
            return null;
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) { /* closed */ }
            if (out != null) try { out.close(); } catch (Exception ignored) { /* closed */ }
        }
    }

    private String collectBehavior() {
        JSONArray apps = new JSONArray();
        int seen = 0;
        try {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> installed = pm.getInstalledApplications(0);
            for (ApplicationInfo info : installed) {
                if (seen >= 400) break;
                boolean system = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean updated = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                if (system && !updated) continue;
                if (getPackageName().equals(info.packageName)) continue;
                seen++;
                PackageInfo pkg;
                try {
                    pkg = pm.getPackageInfo(info.packageName, PackageManager.GET_PERMISSIONS);
                } catch (Exception error) {
                    continue;
                }
                boolean overlay = false;
                boolean sms = false;
                boolean admin = false;
                boolean install = false;
                boolean internet = false;
                JSONArray perms = new JSONArray();
                if (pkg.requestedPermissions != null) {
                    for (String perm : pkg.requestedPermissions) {
                        if ("android.permission.SYSTEM_ALERT_WINDOW".equals(perm)) overlay = true;
                        else if ("android.permission.RECEIVE_SMS".equals(perm) || "android.permission.READ_SMS".equals(perm)) sms = true;
                        else if ("android.permission.REQUEST_INSTALL_PACKAGES".equals(perm)) install = true;
                        else if ("android.permission.BIND_DEVICE_ADMIN".equals(perm)) admin = true;
                        else if ("android.permission.INTERNET".equals(perm)) internet = true;
                        else continue;
                        if (!"android.permission.INTERNET".equals(perm)) perms.put(perm);
                    }
                }
                if (!overlay && !sms && !admin && !install) continue;
                if (internet) perms.put("android.permission.INTERNET");
                try {
                    PackageInfo extra = pm.getPackageInfo(info.packageName, PackageManager.GET_SERVICES | PackageManager.GET_RECEIVERS);
                    if (extra.services != null) {
                        for (android.content.pm.ServiceInfo service : extra.services) {
                            if (service != null && "android.permission.BIND_ACCESSIBILITY_SERVICE".equals(service.permission)) perms.put(service.permission);
                        }
                    }
                    if (extra.receivers != null) {
                        for (android.content.pm.ActivityInfo receiver : extra.receivers) {
                            if (receiver != null && "android.permission.BIND_DEVICE_ADMIN".equals(receiver.permission)) {
                                admin = true;
                                perms.put(receiver.permission);
                            }
                        }
                    }
                } catch (Exception ignored) {
                    /* services stay unread */
                }
                boolean launcher = false;
                try {
                    launcher = pm.getLaunchIntentForPackage(info.packageName) != null;
                } catch (Exception ignored) {
                    launcher = false;
                }
                CharSequence label = info.packageName;
                try {
                    CharSequence read = pm.getApplicationLabel(info);
                    if (read != null) label = read;
                } catch (Exception ignored) {
                    /* package name is enough */
                }
                JSONObject row = new JSONObject();
                row.put("name", label.toString());
                row.put("pkg", info.packageName);
                row.put("path", "apps/" + info.packageName);
                row.put("launcher", launcher);
                row.put("perms", perms);
                apps.put(row);
            }
        } catch (Exception ignored) {
            /* package list unavailable */
        }
        JSONObject root = new JSONObject();
        try {
            root.put("apps", apps);
            root.put("scanned", seen);
        } catch (Exception error) {
            return "{\"apps\":[],\"scanned\":0}";
        }
        return root.toString();
    }

    private String collectTargets(String mode) {
        boolean quick = "quick".equals(mode);
        JSONArray files = new JSONArray();
        boolean downloadsOk = true;
        synchronized (served) {
            served.clear();
        }
        try {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            long cutoff = System.currentTimeMillis() - 14L * 86400000L;
            int added = 0;
            int capCount = quick ? 80 : 400;
            long max = quick ? 48L * 1024L * 1024L : 96L * 1024L * 1024L;
            for (ApplicationInfo info : apps) {
                if (added >= capCount) break;
                boolean system = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean updated = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                if (system && !updated) continue;
                if (info.sourceDir == null) continue;
                PackageInfo pkg;
                try {
                    pkg = pm.getPackageInfo(info.packageName, PackageManager.GET_PERMISSIONS | PackageManager.GET_SERVICES);
                } catch (Exception error) {
                    continue;
                }
                if (quick && pkg.lastUpdateTime < cutoff) continue;
                File apk = new File(info.sourceDir);
                if (!apk.isFile() || apk.length() <= 0 || apk.length() > max) continue;
                String id = UUID.randomUUID().toString();
                synchronized (served) {
                    served.put(id, new Blob(apk, null));
                }
                CharSequence label = pm.getApplicationLabel(info);
                String name = (label == null ? info.packageName : label.toString()) + ".apk";
                JSONObject row = new JSONObject();
                row.put("name", name);
                row.put("path", "apps/" + info.packageName);
                row.put("url", ORIGIN + "/__apk/" + id);
                row.put("pkg", info.packageName);
                JSONArray perms = new JSONArray();
                if (pkg.requestedPermissions != null) {
                    for (String perm : pkg.requestedPermissions) perms.put(perm);
                }
                if (pkg.services != null) {
                    for (android.content.pm.ServiceInfo service : pkg.services) {
                        if (service.permission != null) perms.put(service.permission);
                    }
                }
                row.put("perms", perms);
                files.put(row);
                added++;
            }
        } catch (Exception ignored) {
            /* package list unavailable */
        }
        try {
            addDownloads(files, quick);
        } catch (Exception error) {
            downloadsOk = false;
        }
        JSONObject root = new JSONObject();
        try {
            root.put("files", files);
            root.put("downloads", downloadsOk);
        } catch (Exception error) {
            return "{\"files\":[],\"downloads\":false}";
        }
        return root.toString();
    }

    private void addDownloads(JSONArray files, boolean quick) throws Exception {
        if (Build.VERSION.SDK_INT < 29) return;
        long cutoff = System.currentTimeMillis() / 1000L - 14L * 86400L;
        long max = quick ? 48L * 1024L * 1024L : 96L * 1024L * 1024L;
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                new String[] {MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.SIZE, MediaStore.Downloads.DATE_ADDED},
                null,
                null,
                MediaStore.Downloads.DATE_ADDED + " DESC"
            );
            if (cursor == null) return;
            int n = 0;
            int limit = quick ? 40 : 200;
            while (cursor.moveToNext() && n < limit) {
                long addedAt = cursor.isNull(3) ? 0L : cursor.getLong(3);
                if (quick && addedAt < cutoff) continue;
                long size = cursor.isNull(2) ? -1L : cursor.getLong(2);
                if (size > max) continue;
                String name = cursor.getString(1);
                if (name == null || name.length() == 0) name = "download";
                Uri uri = android.content.ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cursor.getLong(0));
                String id = UUID.randomUUID().toString();
                synchronized (served) {
                    served.put(id, new Blob(null, uri));
                }
                JSONObject row = new JSONObject();
                row.put("name", name);
                row.put("path", "Download/" + name);
                row.put("url", ORIGIN + "/__apk/" + id);
                files.put(row);
                n++;
            }
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private boolean allowedHost(String host, String path) {
        if ("raw.githubusercontent.com".equals(host)) return path != null && path.startsWith("/openphish/public_feed/");
        return "database.clamav.net".equals(host)
            || "packages.microsoft.com".equals(host)
            || "urlhaus.abuse.ch".equals(host)
            || "bazaar.abuse.ch".equals(host)
            || "threatfox.abuse.ch".equals(host)
            || "feodotracker.abuse.ch".equals(host)
            || "openphish.com".equals(host)
            || "rules.emergingthreats.net".equals(host);
    }

    private boolean downloadToCache(String id, String raw) throws Exception {
        if (id == null || !id.matches("[A-Za-z0-9\\-]{8,80}")) return false;
        URL url = new URL(raw);
        if (!"https".equals(url.getProtocol()) || !allowedHost(url.getHost(), url.getPath())) return false;
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(180000);
        conn.setRequestProperty("Accept", "*/*");
        conn.setRequestProperty("User-Agent", "database.clamav.net".equals(url.getHost()) ? "ClamAV/1.4.1" : "Mozilla/5.0 (Linux; Android 14; Kanaf) AppleWebKit/537.36 Chrome/131.0.0.0 Mobile Safari/537.36");
        int code = conn.getResponseCode();
        if (code < 200 || code >= 300) {
            conn.disconnect();
            throw new Exception(String.valueOf(code));
        }
        URL finalUrl = conn.getURL();
        if (finalUrl != null && finalUrl.getProtocol() != null && !"https".equals(finalUrl.getProtocol())) {
            conn.disconnect();
            throw new Exception("redirect");
        }
        String type = conn.getContentType();
        if (type != null && type.toLowerCase(java.util.Locale.US).contains("text/html")) {
            conn.disconnect();
            throw new Exception("html");
        }
        File dir = new File(getCacheDir(), "kanaf-net");
        if (!dir.isDirectory() && !dir.mkdirs()) {
            conn.disconnect();
            return false;
        }
        File dest = new File(dir, id);
        InputStream in = conn.getInputStream();
        FileOutputStream out = new FileOutputStream(dest);
        byte[] buf = new byte[65536];
        long total = 0;
        try {
            int n;
            while ((n = in.read(buf)) >= 0) {
                total += n;
                if (total > 90L * 1024L * 1024L) {
                    dest.delete();
                    return false;
                }
                out.write(buf, 0, n);
            }
        } finally {
            try { out.close(); } catch (Exception ignored) { /* closed */ }
            try { in.close(); } catch (Exception ignored) { /* closed */ }
            conn.disconnect();
        }
        if (total <= 0) {
            dest.delete();
            return false;
        }
        synchronized (netFiles) {
            netFiles.put(id, dest);
        }
        return true;
    }

    private static String junkKind(String name) {
        if (name == null) return "";
        String lower = name.toLowerCase(java.util.Locale.US);
        if (lower.endsWith(".tmp") || lower.endsWith(".temp") || lower.endsWith(".crdownload") || lower.endsWith(".partial") || lower.endsWith(".download") || lower.endsWith(".cache")) return "temp";
        return "";
    }

    private static String cpuHardware() {
        if (Build.VERSION.SDK_INT >= 31) {
            String model = Build.SOC_MODEL;
            String maker = Build.SOC_MANUFACTURER;
            if (model != null && model.length() > 1 && !Build.UNKNOWN.equalsIgnoreCase(model)) {
                if (maker != null && maker.length() > 1 && !Build.UNKNOWN.equalsIgnoreCase(maker) && !model.toLowerCase(java.util.Locale.US).contains(maker.toLowerCase(java.util.Locale.US))) {
                    return maker + " " + model;
                }
                return model;
            }
        }
        java.io.BufferedReader in = null;
        try {
            in = new java.io.BufferedReader(new java.io.FileReader("/proc/cpuinfo"));
            String line;
            while ((line = in.readLine()) != null) {
                String lower = line.toLowerCase(java.util.Locale.US);
                int colon = line.indexOf(':');
                if (colon < 0) continue;
                if (!lower.startsWith("hardware") && !lower.startsWith("model name")) continue;
                String value = line.substring(colon + 1).trim();
                if (value.length() > 1 && !value.matches("\\d+")) return value;
            }
        } catch (Exception ignored) {
            /* fall through */
        } finally {
            if (in != null) try { in.close(); } catch (Exception ignored) { /* closed */ }
        }
        return Build.HARDWARE == null ? "" : Build.HARDWARE;
    }

    private static String sensorLabel(int type) {
        switch (type) {
            case Sensor.TYPE_ACCELEROMETER: return "Accelerometer";
            case Sensor.TYPE_MAGNETIC_FIELD: return "Magnetometer";
            case Sensor.TYPE_GYROSCOPE: return "Gyroscope";
            case Sensor.TYPE_LIGHT: return "Light";
            case Sensor.TYPE_PRESSURE: return "Barometer";
            case Sensor.TYPE_PROXIMITY: return "Proximity";
            case Sensor.TYPE_GRAVITY: return "Gravity";
            case Sensor.TYPE_LINEAR_ACCELERATION: return "Linear acceleration";
            case Sensor.TYPE_ROTATION_VECTOR: return "Rotation";
            case Sensor.TYPE_RELATIVE_HUMIDITY: return "Humidity";
            case Sensor.TYPE_AMBIENT_TEMPERATURE: return "Ambient temperature";
            case Sensor.TYPE_STEP_COUNTER: return "Step counter";
            case Sensor.TYPE_STEP_DETECTOR: return "Step detector";
            case Sensor.TYPE_HEART_RATE: return "Heart rate";
            case Sensor.TYPE_GAME_ROTATION_VECTOR: return "Game rotation";
            case Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR: return "Geomagnetic rotation";
            case Sensor.TYPE_SIGNIFICANT_MOTION: return "Significant motion";
            case Sensor.TYPE_HEART_BEAT: return "Heart beat";
            case Sensor.TYPE_MOTION_DETECT: return "Motion detect";
            case Sensor.TYPE_STATIONARY_DETECT: return "Stationary detect";
            case Sensor.TYPE_HINGE_ANGLE: return "Hinge angle";
            default: return "";
        }
    }

    private static String systemProp(String key) {
        try {
            Class<?> clazz = Class.forName("android.os.SystemProperties");
            java.lang.reflect.Method get = clazz.getMethod("get", String.class, String.class);
            Object value = get.invoke(null, key, "");
            return value instanceof String ? (String) value : "";
        } catch (Exception ignored) {
            return "";
        }
    }

    private static String dateText(String value) {
        if (value == null) return "";
        String text = value.trim();
        if (text.matches("\\d{8}")) return text.substring(0, 4) + "-" + text.substring(4, 6) + "-" + text.substring(6, 8);
        if (text.matches("\\d{4}-\\d{2}-\\d{2}.*")) return text.substring(0, 10);
        return "";
    }

    private static String factoryDate() {
        String[] keys = new String[] {
            "ril.rfcal_date",
            "ril.rfc_date",
            "ril.hw.manufacturing_date",
            "ro.vendor.factory.date",
            "persist.radio.cal.date"
        };
        for (String key : keys) {
            String parsed = dateText(systemProp(key));
            if (parsed.length() > 0) return parsed;
        }
        return "";
    }

    private static String radioName(int type) {
        switch (type) {
            case TelephonyManager.NETWORK_TYPE_GPRS:
            case TelephonyManager.NETWORK_TYPE_EDGE:
            case TelephonyManager.NETWORK_TYPE_CDMA:
            case TelephonyManager.NETWORK_TYPE_1xRTT:
            case TelephonyManager.NETWORK_TYPE_IDEN:
                return "2G";
            case TelephonyManager.NETWORK_TYPE_UMTS:
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
            case TelephonyManager.NETWORK_TYPE_EHRPD:
            case TelephonyManager.NETWORK_TYPE_HSPAP:
                return "3G";
            case TelephonyManager.NETWORK_TYPE_LTE:
            case TelephonyManager.NETWORK_TYPE_IWLAN:
                return "LTE";
            case TelephonyManager.NETWORK_TYPE_NR:
                return "5G";
            default:
                return "";
        }
    }

    private void fillRadios(JSONObject out) throws Exception {
        JSONObject net = new JSONObject();
        String link = "Offline";
        boolean vpn = false;
        try {
            ConnectivityManager connections = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (connections != null) {
                Network active = connections.getActiveNetwork();
                NetworkCapabilities caps = active == null ? null : connections.getNetworkCapabilities(active);
                if (caps != null) {
                    vpn = caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
                    if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) link = "Wi-Fi";
                    else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) link = "Mobile";
                    else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) link = "Ethernet";
                    else link = "Other";
                }
            }
        } catch (Exception ignored) {
            link = "Offline";
        }
        net.put("link", link);
        net.put("vpn", vpn);
        out.put("net", net);
        JSONArray sims = new JSONArray();
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                out.put("phone", "need");
                out.put("sims", sims);
                return;
            }
            out.put("phone", "ok");
            SubscriptionManager subscriptions = (SubscriptionManager) getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE);
            TelephonyManager telephony = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            int dataId = SubscriptionManager.getDefaultDataSubscriptionId();
            java.util.List<SubscriptionInfo> list = subscriptions == null ? null : subscriptions.getActiveSubscriptionInfoList();
            if (list != null) {
                for (SubscriptionInfo info : list) {
                    int slot = info.getSimSlotIndex();
                    if (Build.VERSION.SDK_INT >= 26 && telephony != null && slot >= 0 && telephony.getSimState(slot) != TelephonyManager.SIM_STATE_READY) continue;
                    JSONObject sim = new JSONObject();
                    sim.put("slot", slot + 1);
                    sim.put("kind", Build.VERSION.SDK_INT >= 28 && info.isEmbedded() ? "eSIM" : "SIM");
                    sim.put("operator", info.getCarrierName() == null ? "" : info.getCarrierName().toString());
                    String radio = "";
                    boolean roaming = false;
                    try {
                        TelephonyManager sub = telephony == null ? null : telephony.createForSubscriptionId(info.getSubscriptionId());
                        if (sub != null) {
                            radio = radioName(sub.getDataNetworkType());
                            roaming = sub.isNetworkRoaming();
                        }
                    } catch (Exception ignored) { /* operator name still stands */ }
                    sim.put("radio", radio);
                    sim.put("roaming", roaming);
                    sim.put("data", info.getSubscriptionId() == dataId);
                    sims.put(sim);
                }
            }
        } catch (Exception ignored) {
            if (!out.has("phone")) out.put("phone", "need");
        }
        out.put("sims", sims);
    }

    private JSONObject collectDevice() {
        JSONObject out = new JSONObject();
        try {
            out.put("maker", Build.MANUFACTURER);
            out.put("model", Build.MODEL);
            out.put("device", Build.DEVICE);
            out.put("release", Build.VERSION.RELEASE);
            out.put("sdk", Build.VERSION.SDK_INT);
            out.put("patch", Build.VERSION.SECURITY_PATCH);
        } catch (Exception ignored) { /* identity still useful */ }
        try {
            java.text.SimpleDateFormat day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
            day.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            out.put("built", day.format(new java.util.Date(Build.TIME)));
            out.put("factory", factoryDate());
        } catch (Exception ignored) { /* dates are optional */ }
        try {
            fillRadios(out);
        } catch (Exception ignored) {
            try { out.put("net", new JSONObject().put("link", "Offline").put("vpn", false)); } catch (Exception nested) { /* skip */ }
        }
        try {
            out.put("board", Build.HARDWARE);
            StringBuilder abis = new StringBuilder();
            for (String abi : Build.SUPPORTED_ABIS) {
                if (abis.length() > 0) abis.append(", ");
                abis.append(abi);
            }
            out.put("abis", abis.toString());
            out.put("cores", Runtime.getRuntime().availableProcessors());
            out.put("cpu", cpuHardware());
        } catch (Exception ignored) { /* cpu is optional */ }
        try {
            ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (manager != null) {
                ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
                manager.getMemoryInfo(memory);
                out.put("ramTotal", memory.totalMem);
                out.put("ramFree", memory.availMem);
            }
            StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
            out.put("storeTotal", stat.getTotalBytes());
            out.put("storeFree", stat.getAvailableBytes());
        } catch (Exception ignored) { /* memory is optional */ }
        try {
            BatteryManager battery = (BatteryManager) getSystemService(BATTERY_SERVICE);
            if (battery != null) {
                int level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                if (level >= 0 && level <= 100) out.put("level", level);
                long charge = battery.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
                if (charge > 0) out.put("chargeUah", charge);
            }
            Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (sticky != null) {
                int temp = sticky.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                int voltage = sticky.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
                if (temp >= 0) out.put("temp", temp);
                if (voltage > 0) out.put("voltage", voltage);
                out.put("tech", sticky.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY));
                int status = sticky.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                out.put("charging", status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL);
                if (!out.has("level")) {
                    int scale = sticky.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    int raw = sticky.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    if (raw >= 0 && scale > 0) out.put("level", raw * 100 / scale);
                }
            }
        } catch (Exception ignored) { /* battery is optional */ }
        try {
            android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
            out.put("width", metrics.widthPixels);
            out.put("height", metrics.heightPixels);
            out.put("dpi", metrics.densityDpi);
        } catch (Exception ignored) { /* screen is optional */ }
        try {
            SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            JSONArray sensors = new JSONArray();
            if (sensorManager != null) {
                java.util.LinkedHashMap<String, String> unique = new java.util.LinkedHashMap<String, String>();
                for (Sensor sensor : sensorManager.getSensorList(Sensor.TYPE_ALL)) {
                    String label = sensorLabel(sensor.getType());
                    if (label.length() == 0 || unique.containsKey(label)) continue;
                    String raw = sensor.getName() == null ? "" : sensor.getName().replace(" Non-wakeup", "").replace(" Wakeup", "").trim();
                    unique.put(label, raw);
                    if (unique.size() >= 16) break;
                }
                for (java.util.Map.Entry<String, String> entry : unique.entrySet()) {
                    JSONObject row = new JSONObject();
                    row.put("type", entry.getKey());
                    row.put("name", entry.getValue());
                    sensors.put(row);
                }
            }
            out.put("sensors", sensors);
        } catch (Exception ignored) { /* sensors are optional */ }
        return out;
    }

    private static long deleteChildren(File dir) {
        long freed = 0;
        if (dir == null || !dir.isDirectory()) return 0;
        File[] kids = dir.listFiles();
        if (kids == null) return 0;
        for (File kid : kids) freed += deleteTree(kid);
        return freed;
    }

    private static long deleteTree(File dir) {
        long freed = 0;
        if (dir == null || !dir.exists()) return 0;
        File[] kids = dir.listFiles();
        if (kids != null) {
            for (File kid : kids) freed += kid.isDirectory() ? deleteTree(kid) : kid.length();
        }
        if (dir.isFile()) freed = dir.length();
        dir.delete();
        return freed;
    }

    private final class Bridge {
        @JavascriptInterface
        public void pick(final String kind, final String mode) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startPick(kind, mode);
                }
            });
        }

        @JavascriptInterface
        public String shell() {
            return "android";
        }

        @JavascriptInterface
        public String watching() {
            return prefs().getBoolean("watch", false) ? "on" : "off";
        }

        @JavascriptInterface
        public String network() {
            return networkKind();
        }

        @JavascriptInterface
        public String deviceStatus() {
            return readDevice();
        }

        @JavascriptInterface
        public String listTargets(String mode) {
            return collectTargets(mode);
        }

        @JavascriptInterface
        public String listMessages() {
            return collectMessages();
        }

        @JavascriptInterface
        public String listBehavior() {
            try {
                return collectBehavior();
            } catch (Throwable error) {
                return "{\"apps\":[],\"scanned\":0}";
            }
        }

        @JavascriptInterface
        public String clipboard() {
            final String[] out = new String[] { "" };
            final CountDownLatch latch = new CountDownLatch(1);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        android.content.ClipboardManager manager = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (manager != null && manager.hasPrimaryClip() && manager.getPrimaryClip() != null && manager.getPrimaryClip().getItemCount() > 0) {
                            CharSequence value = manager.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this);
                            if (value != null) out[0] = value.toString();
                        }
                    } catch (Exception ignored) {
                        out[0] = "";
                    } finally {
                        latch.countDown();
                    }
                }
            });
            try {
                latch.await(2, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            return out[0];
        }

        @JavascriptInterface
        public void askSms() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (checkSelfPermission(android.Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                        deliverPerm(true);
                        return;
                    }
                    requestPermissions(new String[] {android.Manifest.permission.READ_SMS}, 78);
                }
            });
        }

        @JavascriptInterface
        public void fetchUrl(final String id, final String url) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    boolean ok = false;
                    String reason = "";
                    try {
                        ok = downloadToCache(id, url);
                    } catch (Exception error) {
                        ok = false;
                        reason = error.getMessage() == null ? "download" : error.getMessage();
                    }
                    final boolean done = ok;
                    final String why = reason;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (web == null) return;
                            String script = "window.__kanafNet&&window.__kanafNet(" + JSONObject.quote(id) + "," + (done ? "true" : "false") + "," + JSONObject.quote(why) + ")";
                            web.evaluateJavascript(script, null);
                        }
                    });
                }
            }, "kanaf-net").start();
        }

        @JavascriptInterface
        public String setWatch(final boolean on) {
            prefs().edit().putBoolean("watch", on).apply();
            try {
                Intent intent = new Intent(MainActivity.this, WatchService.class);
                intent.setAction(on ? WatchService.ACTION_START : WatchService.ACTION_STOP);
                if (on && Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
                else startService(intent);
                return "ok";
            } catch (Exception error) {
                return "fail";
            }
        }

        @JavascriptInterface
        public void askNotify() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT < 33) {
                        deliverPerm(true);
                        return;
                    }
                    if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        deliverPerm(true);
                        return;
                    }
                    requestPermissions(new String[] {android.Manifest.permission.POST_NOTIFICATIONS}, 77);
                }
            });
        }

        @JavascriptInterface
        public void setCallPolicy(String json) {
            if (json == null || json.length() > 20000) return;
            prefs().edit().putString("call-policy", json).apply();
        }

        @JavascriptInterface
        public String callRole() {
            if (Build.VERSION.SDK_INT < 29) return "old";
            RoleManager roles = (RoleManager) getSystemService(ROLE_SERVICE);
            if (roles == null || !roles.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) return "missing";
            return roles.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) ? "held" : "available";
        }

        @JavascriptInterface
        public void askCallRole() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT < 29) return;
                    RoleManager roles = (RoleManager) getSystemService(ROLE_SERVICE);
                    if (roles == null || !roles.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) return;
                    if (roles.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) return;
                    startActivityForResult(roles.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 81);
                }
            });
        }

        @JavascriptInterface
        public String askClearAppCache() {
            final String[] result = new String[] {"fail"};
            final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    result[0] = launchClearCache();
                    latch.countDown();
                }
            });
            try {
                latch.await(2, java.util.concurrent.TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            return result[0];
        }

        private String launchClearCache() {
            Intent clear = new Intent(StorageManager.ACTION_CLEAR_APP_CACHE);
            if (clear.resolveActivity(getPackageManager()) != null) {
                try {
                    startActivity(clear);
                    return "ok";
                } catch (Exception ignored) {
                    /* this phone hides the system cache screen */
                }
            }
            return "fail";
        }

        @JavascriptInterface
        public String listUserApps() {
            JSONArray rows = new JSONArray();
            try {
                java.util.List<PackageInfo> packs = getPackageManager().getInstalledPackages(0);
                java.util.List<JSONObject> found = new java.util.ArrayList<JSONObject>();
                for (PackageInfo info : packs) {
                    if (info.applicationInfo == null) continue;
                    if ((info.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                    if (getPackageName().equals(info.packageName)) continue;
                    JSONObject row = new JSONObject();
                    row.put("pkg", info.packageName);
                    row.put("name", info.applicationInfo.loadLabel(getPackageManager()).toString());
                    found.add(row);
                }
                java.util.Collections.sort(found, new java.util.Comparator<JSONObject>() {
                    @Override
                    public int compare(JSONObject a, JSONObject b) {
                        return a.optString("name").compareToIgnoreCase(b.optString("name"));
                    }
                });
                int n = 0;
                for (JSONObject row : found) {
                    if (n >= 80) break;
                    rows.put(row);
                    n++;
                }
            } catch (Exception ignored) {
                return "[]";
            }
            return rows.toString();
        }

        @JavascriptInterface
        public void openAppInfo(final String pkg) {
            if (pkg == null || !pkg.matches("[A-Za-z][A-Za-z0-9_\\.]*") || pkg.length() > 180) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        intent.setData(Uri.parse("package:" + pkg));
                        startActivity(intent);
                    } catch (Exception ignored) {
                        /* no app page */
                    }
                }
            });
        }

        @JavascriptInterface
        public String filesAccess() {
            if (Build.VERSION.SDK_INT < 30) return "ok";
            return Environment.isExternalStorageManager() ? "ok" : "need";
        }

        @JavascriptInterface
        public void askFilesAccess() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception error) {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                        } catch (Exception ignored) {
                            /* no files screen */
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void askPhoneState() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        if (web != null) web.evaluateJavascript("window.__kanafDevice&&window.__kanafDevice()", null);
                        return;
                    }
                    requestPermissions(new String[] {android.Manifest.permission.READ_PHONE_STATE}, 79);
                }
            });
        }

        @JavascriptInterface
        public String deviceInfo() {
            final JSONObject[] box = new JSONObject[] { new JSONObject() };
            final java.util.concurrent.CountDownLatch latch = new java.util.concurrent.CountDownLatch(1);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    box[0] = collectDevice();
                    latch.countDown();
                }
            });
            try {
                latch.await(2, java.util.concurrent.TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            return box[0].toString();
        }

        @JavascriptInterface
        public String clearOwnCache() {
            long freed = 0;
            freed += deleteChildren(getCacheDir());
            freed += deleteChildren(getExternalCacheDir());
            freed += deleteChildren(getCodeCacheDir());
            final WebView page = web;
            if (page != null) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        page.clearCache(true);
                    }
                });
            }
            return Long.toString(freed);
        }

        @JavascriptInterface
        public String listJunk() {
            JSONArray rows = new JSONArray();
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) return "[]";
            File root = Environment.getExternalStorageDirectory();
            File[] dirs = new File[] {
                new File(root, "Download"),
                new File(root, "Downloads"),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            };
            java.util.HashSet<String> seen = new java.util.HashSet<String>();
            for (File dir : dirs) collectJunk(dir, rows, seen, 0);
            return rows.toString();
        }

        private void collectJunk(File dir, JSONArray rows, java.util.HashSet<String> seen, int depth) {
            if (dir == null || depth > 3 || rows.length() >= 60 || !dir.isDirectory()) return;
            File[] kids = dir.listFiles();
            if (kids == null) return;
            for (File kid : kids) {
                if (rows.length() >= 60) return;
                if (kid.isDirectory()) {
                    String lower = kid.getName().toLowerCase(java.util.Locale.US);
                    if (lower.equals("android") || lower.equals("dcim") || lower.equals("pictures") || lower.equals("movies") || lower.equals("music")) continue;
                    collectJunk(kid, rows, seen, depth + 1);
                    continue;
                }
                if (junkKind(kid.getName()).length() == 0) continue;
                try {
                    String path = kid.getCanonicalPath();
                    if (!seen.add(path)) continue;
                    JSONObject row = new JSONObject();
                    row.put("id", path);
                    row.put("name", kid.getName());
                    row.put("size", kid.length());
                    row.put("kind", junkKind(kid.getName()));
                    rows.put(row);
                } catch (Exception ignored) {
                    /* skip unreadable */
                }
            }
        }

        @JavascriptInterface
        public String deleteJunk(String json) {
            if (json == null) return "0";
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) return "need";
            long freed = 0;
            try {
                File root = Environment.getExternalStorageDirectory().getCanonicalFile();
                JSONArray ids = new JSONArray(json);
                for (int i = 0; i < ids.length() && i < 40; i++) {
                    File file = new File(ids.getString(i)).getCanonicalFile();
                    if (!file.getPath().startsWith(root.getPath() + File.separator)) continue;
                    if (!file.isFile() || junkKind(file.getName()).length() == 0) continue;
                    long size = file.length();
                    if (file.delete()) freed += size;
                }
            } catch (Exception ignored) {
                return "0";
            }
            return Long.toString(freed);
        }

        @JavascriptInterface
        public String saveText(String name, String body) {
            if (Build.VERSION.SDK_INT < 29 || body == null) return "old";
            if (body.length() > 200000) body = body.substring(0, 200000);
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, "kanaf-decisions.txt");
                values.put(MediaStore.Downloads.MIME_TYPE, "text/plain");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return "fail";
                java.io.OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) return "fail";
                try {
                    out.write(body.getBytes("UTF-8"));
                } finally {
                    out.close();
                }
                return "ok";
            } catch (Exception error) {
                return "fail";
            }
        }

        @JavascriptInterface
        public void note(String body) {
            if (body == null) return;
            String clean = body.replace('\n', ' ').replace('\r', ' ');
            if (clean.length() > 80) clean = clean.substring(0, 80);
            WatchService.ping(MainActivity.this, clean);
        }

        @JavascriptInterface
        public String notices() {
            String flat = android.provider.Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
            return flat != null && flat.contains(getPackageName()) ? "on" : "off";
        }

        @JavascriptInterface
        public String pendingNotice() {
            return prefs().getString("pending-notice", "");
        }

        @JavascriptInterface
        public String pendingHashes() {
            return prefs().getString("pending-hash", "[]");
        }

        @JavascriptInterface
        public String pendingCerts() {
            return prefs().getString("pending-certs", "[]");
        }

        @JavascriptInterface
        public void askCamera() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        if (web != null) web.evaluateJavascript("window.__kanafCamera&&window.__kanafCamera(true)", null);
                        return;
                    }
                    requestPermissions(new String[] {android.Manifest.permission.CAMERA}, 80);
                }
            });
        }

        @JavascriptInterface
        public void pickNumbers() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("*/*");
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(intent, PICK_TEXT);
                    } catch (Exception ignored) {
                        if (web != null) web.evaluateJavascript("window.__kanafNumbers&&window.__kanafNumbers('')", null);
                    }
                }
            });
        }

        @JavascriptInterface
        public void clearPending() {
            prefs().edit().remove("pending-notice").remove("pending-hash").remove("pending-certs").apply();
        }

        @JavascriptInterface
        public String integrity() {
            try {
                int flags = Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
                PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), flags);
                Signature[] sigs;
                if (Build.VERSION.SDK_INT >= 28 && info.signingInfo != null) sigs = info.signingInfo.getApkContentsSigners();
                else sigs = info.signatures;
                if (sigs == null || sigs.length == 0) return "unknown";
                byte[] dig = MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray());
                StringBuilder hex = new StringBuilder(dig.length * 2);
                for (byte b : dig) hex.append(String.format("%02x", b));
                return SIGNER.equals(hex.toString()) ? "ok" : "repacked";
            } catch (Exception error) {
                return "unknown";
            }
        }

        @JavascriptInterface
        public void uninstall(final String pkg) {
            if (pkg == null || !pkg.matches("[A-Za-z0-9_.]+")) return;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg)));
                    } catch (Exception ignored) {
                        /* no installer */
                    }
                }
            });
        }

        @JavascriptInterface
        public void openSettings(final String kind) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String action;
                    if ("notices".equals(kind)) action = Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS;
                    else if ("security".equals(kind)) action = Settings.ACTION_SECURITY_SETTINGS;
                    else action = Settings.ACTION_SETTINGS;
                    try {
                        startActivity(new Intent(action));
                    } catch (Exception error) {
                        try {
                            startActivity(new Intent(Settings.ACTION_SETTINGS));
                        } catch (Exception ignored) {
                            /* settings unavailable */
                        }
                    }
                }
            });
        }
    }

    private void startPick(String kind, String mode) {
        if (picking) return;
        picking = true;
        pickMode = mode == null ? "deep" : mode;
        synchronized (picked) {
            picked.clear();
            names.clear();
        }
        try {
            if ("files".equals(kind)) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent, PICK_FILES);
            } else {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_TREE);
            }
        } catch (Exception error) {
            picking = false;
            deliver(null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_CHOOSER) {
            android.net.Uri[] uris = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    uris = new android.net.Uri[count];
                    for (int i = 0; i < count; i++) uris[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    uris = new android.net.Uri[] { data.getData() };
                }
            }
            if (fileCallback != null) fileCallback.onReceiveValue(uris);
            fileCallback = null;
            return;
        }
        if (requestCode == PICK_TEXT) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                if (web != null) web.evaluateJavascript("window.__kanafNumbers&&window.__kanafNumbers('')", null);
                return;
            }
            final Uri uri = data.getData();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String text = "";
                    try {
                        java.io.InputStream in = getContentResolver().openInputStream(uri);
                        if (in != null) {
                            java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
                            byte[] chunk = new byte[4096];
                            int n;
                            int total = 0;
                            while ((n = in.read(chunk)) >= 0 && total < 200000) {
                                buf.write(chunk, 0, n);
                                total += n;
                            }
                            in.close();
                            text = buf.toString("UTF-8");
                        }
                    } catch (Exception ignored) {
                        text = "";
                    }
                    final String payload = org.json.JSONObject.quote(text);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (web != null) web.evaluateJavascript("window.__kanafNumbers&&window.__kanafNumbers(" + payload + ")", null);
                        }
                    });
                }
            }, "kanaf-numbers").start();
            return;
        }
        if (requestCode != PICK_TREE && requestCode != PICK_FILES) return;
        if (resultCode != RESULT_OK || data == null) {
            picking = false;
            deliver(null);
            return;
        }
        final Intent chosen = data;
        final boolean tree = requestCode == PICK_TREE;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (tree) collectTree(chosen);
                    else collectFiles(chosen);
                    deliver(manifest());
                } catch (Exception error) {
                    deliver(null);
                } finally {
                    picking = false;
                }
            }
        }, "kanaf-pick").start();
    }

    private void collectFiles(Intent data) {
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount() && countPicked() < MAX_FILES; i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri == null) continue;
                String name = displayName(uri);
                remember(uri, name, name);
            }
            return;
        }
        Uri uri = data.getData();
        if (uri == null) return;
        String name = displayName(uri);
        remember(uri, name, name);
    }

    private void collectTree(Intent data) {
        Uri tree = data.getData();
        if (tree == null) return;
        int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
        try {
            getContentResolver().takePersistableUriPermission(tree, flags);
        } catch (Exception ignored) {
            /* one-shot read is enough */
        }
        String treeId = DocumentsContract.getTreeDocumentId(tree);
        Uri root = DocumentsContract.buildDocumentUriUsingTree(tree, treeId);
        String rootName = displayName(root);
        if (rootName == null || rootName.length() == 0) rootName = "folder";
        ArrayDeque<String[]> queue = new ArrayDeque<String[]>();
        queue.add(new String[] {treeId, rootName});
        String[] projection = new String[] {
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        };
        long cap = "quick".equals(pickMode) ? 64L * 1024L * 1024L : 256L * 1024L * 1024L;
        while (!queue.isEmpty() && countPicked() < MAX_FILES) {
            String[] item = queue.removeFirst();
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, item[0]);
            Cursor cursor = null;
            try {
                cursor = getContentResolver().query(children, projection, null, null, null);
                if (cursor == null) continue;
                int idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                int sizeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
                while (cursor.moveToNext() && countPicked() < MAX_FILES) {
                    String id = idCol >= 0 ? cursor.getString(idCol) : null;
                    if (id == null) continue;
                    String name = nameCol >= 0 ? cursor.getString(nameCol) : "file";
                    if (name == null || name.length() == 0) name = "file";
                    String mime = mimeCol >= 0 ? cursor.getString(mimeCol) : "";
                    long size = sizeCol >= 0 && !cursor.isNull(sizeCol) ? cursor.getLong(sizeCol) : -1L;
                    String path = item[1] + "/" + name;
                    if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                        queue.add(new String[] {id, path});
                        continue;
                    }
                    if (size > cap) continue;
                    Uri uri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                    remember(uri, name, path);
                }
            } catch (Exception ignored) {
                /* skip unreadable directories */
            } finally {
                if (cursor != null) cursor.close();
            }
        }
    }

    private void remember(Uri uri, String name, String path) {
        String id = UUID.randomUUID().toString();
        synchronized (picked) {
            picked.put(id, uri);
        }
        names.put(id, new String[] {name, path});
    }

    private final Map<String, String[]> names = new LinkedHashMap<String, String[]>();

    private int countPicked() {
        synchronized (picked) {
            return picked.size();
        }
    }

    private String manifest() {
        JSONArray files = new JSONArray();
        synchronized (picked) {
            for (Map.Entry<String, Uri> entry : picked.entrySet()) {
                String[] meta = names.get(entry.getKey());
                String name = meta == null ? "file" : meta[0];
                String path = meta == null ? name : meta[1];
                JSONObject row = new JSONObject();
                try {
                    row.put("name", name);
                    row.put("path", path);
                    row.put("url", ORIGIN + "/__picked/" + entry.getKey());
                    files.put(row);
                } catch (Exception ignored) {
                    /* skip a row that cannot be encoded */
                }
            }
        }
        JSONObject root = new JSONObject();
        try {
            root.put("files", files);
        } catch (Exception ignored) {
            return "{\"files\":[]}";
        }
        return root.toString();
    }

    private String displayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && name.length() > 0) return name;
                }
            }
        } catch (Exception ignored) {
            /* fall through */
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = uri.getLastPathSegment();
        return last == null || last.length() == 0 ? "file" : last;
    }

    private void deliver(final String json) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web == null) return;
                String script = json == null
                    ? "window.__kanafDeliver&&window.__kanafDeliver(null)"
                    : "window.__kanafDeliver&&window.__kanafDeliver(" + JSONObject.quote(json) + ")";
                web.evaluateJavascript(script, null);
            }
        });
    }

    private WebResourceResponse intercept(Uri uri) {
        if (uri == null || !HOST.equals(uri.getHost())) return null;
        String path = uri.getPath();
        if (path == null || path.length() == 0) path = "/";
        if (path.startsWith("/")) path = path.substring(1);
        int cut = path.indexOf('?');
        if (cut >= 0) path = path.substring(0, cut);
        if (path.contains("..")) return missing();
        if (path.startsWith("__picked/")) return pickedFile(path.substring("__picked/".length()));
        if (path.startsWith("__apk/")) return servedFile(path.substring("__apk/".length()));
        if (path.startsWith("__mms/")) return mailFile(path.substring("__mms/".length()));
        if (path.startsWith("__net/")) return netFile(path.substring("__net/".length()));
        if (path.length() == 0) path = "index.html";
        InputStream body = openAsset(path);
        if (body == null && isNavigation(path)) body = openAsset("index.html");
        if (body == null) return missing();
        return new WebResourceResponse(mime(path), charset(path), body);
    }

    private WebResourceResponse servedFile(String id) {
        int slash = id.indexOf('/');
        if (slash >= 0) id = id.substring(0, slash);
        Blob blob;
        synchronized (served) {
            blob = served.get(id);
        }
        if (blob == null) return missing();
        try {
            InputStream body = blob.file != null ? new java.io.FileInputStream(blob.file) : getContentResolver().openInputStream(blob.uri);
            if (body == null) return missing();
            return new WebResourceResponse("application/octet-stream", null, body);
        } catch (Exception error) {
            return missing();
        }
    }

    private WebResourceResponse netFile(String id) {
        int slash = id.indexOf('/');
        if (slash >= 0) id = id.substring(0, slash);
        File file;
        synchronized (netFiles) {
            file = netFiles.get(id);
        }
        if (file == null || !file.isFile()) return missing();
        try {
            return new WebResourceResponse("application/octet-stream", null, new java.io.FileInputStream(file));
        } catch (Exception error) {
            return missing();
        }
    }

    private WebResourceResponse pickedFile(String id) {
        int slash = id.indexOf('/');
        if (slash >= 0) id = id.substring(0, slash);
        Uri uri;
        synchronized (picked) {
            uri = picked.get(id);
        }
        if (uri == null) return missing();
        try {
            InputStream body = getContentResolver().openInputStream(uri);
            if (body == null) return missing();
            return new WebResourceResponse("application/octet-stream", null, body);
        } catch (FileNotFoundException error) {
            return missing();
        } catch (SecurityException error) {
            return missing();
        }
    }

    private InputStream openAsset(String path) {
        try {
            return getAssets().open(path);
        } catch (Exception error) {
            return null;
        }
    }

    private boolean isNavigation(String path) {
        int slash = path.lastIndexOf('/');
        String last = slash >= 0 ? path.substring(slash + 1) : path;
        return last.length() == 0 || last.indexOf('.') < 0;
    }

    private WebResourceResponse missing() {
        return new WebResourceResponse(
            "text/plain",
            "utf-8",
            404,
            "Not Found",
            new LinkedHashMap<String, String>(),
            new ByteArrayInputStream(new byte[0])
        );
    }

    private String mime(String path) {
        String lower = path.toLowerCase(Locale.US);
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "text/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".json") || lower.endsWith(".map")) return "application/json";
        if (lower.endsWith(".webmanifest")) return "application/manifest+json";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".ico")) return "image/x-icon";
        if (lower.endsWith(".woff2")) return "font/woff2";
        if (lower.endsWith(".woff")) return "font/woff";
        if (lower.endsWith(".ttf")) return "font/ttf";
        if (lower.endsWith(".txt") || lower.endsWith(".tsv")) return "text/plain";
        if (lower.endsWith(".wasm")) return "application/wasm";
        if (lower.endsWith(".xml")) return "application/xml";
        return "application/octet-stream";
    }

    private String charset(String path) {
        String type = mime(path);
        if (type.startsWith("text/") || type.contains("javascript") || type.contains("json") || type.endsWith("+xml")) {
            return "utf-8";
        }
        return null;
    }
}
